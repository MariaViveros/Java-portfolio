import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author majoviveros
 */
public class MouseRollover extends Application 
{
    public static void main(String[] args) 
    {
        launch(args);  
    }
    
    @Override
    public void start(Stage primaryStage)
    {
        final double WIDTH = 610.0;
        final double HEIGHT = 610.0;
       
        Image flower1 = new Image("flower_01.jpg");
        ImageView imageView = new ImageView(flower1);
       
        Image flower2 = new Image("flower_02.jpg");
        
        imageView.setOnMouseEntered(e -> 
        {
            imageView.setImage(flower2);
        });
        
        imageView.setOnMouseExited(e -> 
        {
            imageView.setImage(flower1);
        });
       
        Pane pane = new Pane(imageView);
       
        Scene scene = new Scene(pane, WIDTH, HEIGHT);
        primaryStage.setScene(scene);
	primaryStage.show();
    }    
}
