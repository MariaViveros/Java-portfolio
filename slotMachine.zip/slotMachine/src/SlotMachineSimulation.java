import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * This class will make the required connections
 * to run the application created in SceneBuilder 
 * with the controller created with javafx
 */
public class SlotMachineSimulation extends Application
{
    public static void main(String[] args) 
    {
        // Launch the application.
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) throws IOException
    {
        // Create the FXML Loader
        FXMLLoader loader = new FXMLLoader();
        
        Parent root = loader.load(getClass().
                getResource("SlotMachineSimulation.fxml"));
        
        // Create a Scene and display the pane
	Scene scene = new Scene(root);
	primaryStage.setScene(scene);
	primaryStage.show();
    }
}
