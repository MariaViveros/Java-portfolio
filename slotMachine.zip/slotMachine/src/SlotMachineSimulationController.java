import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * This class is the controller for the application,
 * where all events are handled
 */

public class SlotMachineSimulationController
{
    // Create a new random variable
    Random rand = new Random();
    
    // Create an int variable to change the image
    int image;
    
    @FXML 
    // The reference of firstImage will be get by the fxml loader
    private ImageView firstImage;
    
    @FXML 
    // The reference of secondImage will be get by the fxml loader
    private ImageView secondImage;
    
    @FXML 
    // The reference of thirdImage will be get by the fxml loader
    private ImageView thirdImage;
    
    @FXML 
    // The reference of inputAmount will be get by the fxml loader
    private TextField inputAmount;  
    
    @FXML
    // The reference of thisAmount will be get by the fxml loader
    private Label thisAmount; 
    
    @FXML
    // The reference of totalAmount will be get by the fxml loader
    private Label totalAmount; 
    
    // Create new Image elements for each image
    Image apple = new Image("Apple.png");
    Image banana = new Image("Banana.png");
    Image cherries = new Image("Cherries.png");
    Image grapes = new Image("Grapes.png");
    Image lemon = new Image("Lemon.png");
    Image lime = new Image("Lime.png");
    Image orange = new Image("Orange.png");
    Image pear = new Image("Pear.png");
    Image strawberry = new Image("Strawberry.png");
    Image watermelon = new Image("Watermelon.png");
    
    // Create a variable to keep images' ID
    int imgID;
    // Create a variable to keep the won on every round
    int won = 0;
    // Create a variable to keep record of every won
    int totalWon = 0;
    
    /**
     * Public method to control what happens when the spin
     * button is pressed.
     * 
     * @param e 
     */
    @FXML 
    public void spin(ActionEvent e)
    { 
        // Create a try/catch clause in case the input is empty
        try
        {
            // Get the input from the user
            String inputText = inputAmount.getText();
            // Convert the text input to int
            int input = Integer.parseInt(inputText);
            // Create an int array to keep images' ID
            int[] imagesID = new int[3];

            // Create a for cycle to change all pictures
            for(int index = 0; index < 3; index++)
            {
                // Create an Image and ImageView element to keep the random selection
                Image img;
                ImageView imgView;
                // Create a random number to get a random image
                image = rand.nextInt(10);

                // Create a switch case loop to get the random images
                switch(image)
                {
                    case 1: img = apple; imgID = 1; break;
                    case 2: img = banana; imgID = 2; break;
                    case 3: img = cherries; imgID = 3; break;
                    case 4: img = grapes; imgID = 4; break;
                    case 5: img = lemon; imgID = 5; break;
                    case 6: img = lime; imgID = 6; break;
                    case 7: img = orange; imgID = 7; break;
                    case 8: img = pear; imgID = 8; break;
                    case 9: img = strawberry; imgID = 9; break;
                    default: img = watermelon; imgID = 10; 
                }

                // Create a switch case loop to change all 3 ImageView
                switch(index)
                {
                    case 0: imgView = firstImage; break;
                    case 1: imgView = secondImage; break;
                    default: imgView = thirdImage; 
                }

                // Set the Image of each ImageView
                imgView.setImage(img);
                // Get the array with all chosen images ID
                imagesID[index] = imgID;
            }

            // if all images are different, the won is $0
            if(imagesID[0] != imagesID[1] && imagesID[0] != imagesID[2] &&
                    imagesID[1] != imagesID[2])
                won = 0;
            // if all images are the same, the won is 3 times the input
            else if(imagesID[0] == imagesID[1] && imagesID[1] == imagesID[2])
                won = input * 3;
            // if two images are the same, the won is 2 times the input
            else
                won = input * 2;

            // Add what they own in this round with the amount already won
            totalWon += won;

            // Change Label's text to know what they won
            thisAmount.setText(Integer.toString(won));  
            totalAmount.setText(Integer.toString(totalWon));
        }
        // Throw an exception if input is empty
        catch(Exception ex)
        {
            // Change the TextField text so the user know it is required
            inputAmount.setText("Required");
        }
    }
}
