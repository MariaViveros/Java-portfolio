/** A demonstration of the class ArrayBag
    @author Frank M. Carrano
    @author Timothy M. Henry
    @version 4.0
*/
public class ArrayBagDemo
{
	public static void main(String[] args) 
	{
		String[] contentsOfBag = {"A", "B", "C", "D", "E", "F"};

		// Tests on an empty bag
		BagInterface<String> aBag = new ArrayBag<>(contentsOfBag.length);

		testAdd(aBag, contentsOfBag);
		//displayBag(aBag);
	} // end main
   
	// Tests the method add.
	private static void testAdd(BagInterface<String> aBag, String[] content)
	{
		System.out.print("Adding ");
		for (int index = 0; index < content.length; index++)
		{
			aBag.add(content[index]);
			System.out.print(content[index] + " ");
		} // end for
		System.out.println();
      
		displayBag(aBag);
	} // end testAdd

	// Tests the method toArray while displaying the bag.
	private static void displayBag(BagInterface<String> aBag)
	{
		System.out.println("The bag contains " + aBag.getCurrentSize() +
                           " string(s), as follows:");     
		Object[] bagArray = aBag.toArray();
		for (int index = 0; index < bagArray.length; index++)
		{
			System.out.print(bagArray[index] + " ");
		} // end for
      
		System.out.println();
                int bagLength = bagArray.length - 1;
                reverseArray(aBag, bagLength);
	} // end displayBag
        
        /**
         * Method to print the given array in reverse
         * @param aBag      Given bag to convert in array and print it
         * @param length    Number of times that the method will be repeated (array size)
         */
        private static void reverseArray(BagInterface<String> aBag, int length)
        {
            System.out.println("The bag in reverse order is: ");
            // Convert bag into array
            Object[] bagArray = aBag.toArray();
            
            // Make a while loop for recursion
            while(length >= 0)
            {
                // Print the array element
                System.out.print(bagArray[length] + " ");
                // Remove one from the length variable,
                length--;
            }
            
            System.out.println();
        } // end reverseArray
} // end ArrayBagDemo
