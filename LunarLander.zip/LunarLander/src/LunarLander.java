import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LunarLander extends Application
{
    public static void main(String[] args) 
    {
        // Launch the application.
	launch(args);
    }
    
    @Override
    public void start(Stage primaryStage)
    {
        // Constants for the size of the scene
        final double WIDTH = 625.0;
        final double HEIGHT = 475.0;
        
        // Constants for the transition
        final double THREE_SEC = 3000.0;
        
        // Create a Border Pane
        //BorderPane borderPane = new BorderPane();
        
        // Create an Image and ImageView for the background
        Image background = new Image("img/lunar surface.png");
        ImageView imageViewBg = new ImageView(background);
        
        // Set the background Image
        //borderPane.setCenter(imageViewBg);
        
        // Create an Image and ImageView for the lunar lander
        Image lander = new Image("img/lunar lander.png");
        ImageView imageViewLander = new ImageView(lander);
        
        // Create the transition object for the first part 
        TranslateTransition trans1 = new TranslateTransition(
                new Duration(THREE_SEC),imageViewLander);
        trans1.setFromX(0.0);
        trans1.setFromY(250.0);
        trans1.setToX(300.0);
        trans1.setToY(250.0);
        
        // Create the transition object for the second part 
        TranslateTransition trans2 = new TranslateTransition(
                new Duration(THREE_SEC),imageViewLander);
        trans2.setFromX(300.0);
        trans2.setFromY(250.0);
        trans2.setToX(300.0);
        trans2.setToY(-100.0);
        
        // Create a Pane to display both images
        Pane pane = new Pane(imageViewBg, imageViewLander);

        // Create a Scene and display the pane
	Scene scene = new Scene(pane, WIDTH, HEIGHT);
	primaryStage.setScene(scene);
	primaryStage.show();
        
        // Create an On click event to start the second animation
        scene.setOnKeyPressed (e -> 
        {
            trans2.play();
        });
        
        // Play the first animation
        trans1.play();
    }
    
}
