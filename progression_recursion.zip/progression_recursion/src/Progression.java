import java.util.Scanner;

/**
   This program calculates the geometric and
   harmonic progression for a number entered
   by the user.
*/

public class Progression
{
    public static void main(String[] args)
    {
	Scanner keyboard = new Scanner (System.in);

	System.out.println("This program will calculate " +
                        "the geometric and harmonic " +
                        "progression for the number " +
                        "you enter.");
                         
	System.out.print("Enter an integer that is " +
                        "greater than or equal to 1: ");
                       
	int input = keyboard.nextInt();

	// Match the method calls with the methods you write
	int geomAnswer = geometricRecursive(input);
	double harmAnswer = harmonicRecursive(input);

	System.out.println("Using recursion:");
      
	System.out.println("The geometric progression of " +
                        input + " is " + geomAnswer);
                         
	System.out.println("The harmonic progression of " +
                        input + " is " + harmAnswer);

	// Match the method calls with the methods you write
	geomAnswer = geometricIterative(input);
	harmAnswer = harmonicIterative(input);

	System.out.println("Using iteration:");
	System.out.println("The geometric progression of " +
                        input + " is " + geomAnswer);
                         
	System.out.println("The harmonic progression of " +
                        input + " is " + harmAnswer);
    }

    // Create a variable to keep geometric recursive result
    static int geometricResult = 1; 
    // Create a variable to keep harmonic recursive result
    static double harmonicResult = 1; 
        
    /**
     * Method to get geometric progression using recursion
     * @param input Given number by the user for which we'll get the progression 
     * @return result of geometric progression
     */
    private static int geometricRecursive(int input)
    {   
        if(input > 0)
        {
            geometricResult *= input;
            input --;
            geometricRecursive(input);
        }
        return geometricResult;
    }
        
    /**
     * Method to get geometric progression using iteration
     * @param input Given number by the user for which we'll get the progression 
     * @return result of geometric progression
     */
    private static int geometricIterative(int input)
    {
        int answer = 1;
            
        for (int index = 1; index <= input; index++)
        {
            answer *= index;
        }
            
        return answer;
    }
        
    /**
     * Method to get harmonic progression using recursion
     * @param input Given number by the user for which we'll get the progression 
     * @return result of harmonic progression
     */
    private static double harmonicRecursive(int input)
    {
        if(input > 0)
        {
            harmonicResult *= 1.0/input;
            input --;
            harmonicRecursive(input);
        }
        return harmonicResult;
    }
        
    /**
     * Method to get harmonic progression using iteration
     * @param input Given number by the user for which we'll get the progression 
     * @return result of harmonic progression
     */
    private static double harmonicIterative(int input)
    {
        double answer = 1.0;
            
        for (int index = 1; index <= input; index++)
        {
            answer *= 1.0/index;
        }
            
        return answer;
    }
}
