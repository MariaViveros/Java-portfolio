/**
 * EmptyName exceptions are thrown by the Payroll
 * class when an empty string Empty String given 
 * for the employee's name.
 *
 */
public class EmptyName extends Exception {
    
    /**
     * Create a generic message for the constructor
     */
    public EmptyName()
    {
        super("Error: You must enter a valid name.");
    }
}
