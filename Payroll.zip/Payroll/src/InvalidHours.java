/**
 * InvalidHours exceptions are thrown by the Payroll
 * class when an invalid number is given for the hours 
 * worked. An invalid number would be a negative number,
 * or greater than 84.
 *
 */

public class InvalidHours extends Exception {
    /**
     * Create a generic message for the constructor
     */
    public InvalidHours()
    {
        super("Error: You must enter a valid number "
                + "of hours worked.");
    }
}
