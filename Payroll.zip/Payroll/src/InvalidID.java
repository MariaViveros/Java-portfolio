/**
 * InvalidID exceptions are thrown by the Payroll
 * class when an invalid value is given for the employee's 
 * ID number, in this case, a negative number, or 0.
 *
 */

public class InvalidID extends Exception {
    /**
     * Create a generic message for the constructor
     */
    public InvalidID()
    {
        super("Error: You must enter a valid ID number.");
    }
}
