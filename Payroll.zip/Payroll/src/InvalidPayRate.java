/**
 * InvalidPayRate exceptions are thrown by the Payroll
 * class when an invalid number is given for the hourly 
 * pay rate. An invalid number would be a negative number,
 * or greater than 25.
 *
 */

public class InvalidPayRate extends Exception {
    /**
     * Create a generic message for the constructor
     */
    public InvalidPayRate()
    {
        super("Error: You must enter a valid number "
                + "of hourly pay rate.");
    }
}
