import java.util.Scanner;
        
public class PalindromeDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create a new character stack
        StackInterface<Character> stack = new LinkedStack<>();
        // Create a variable for the scanner
        Scanner s = new Scanner(System.in);
        String entryString; // Create a variable for the input string
        String outputString = ""; // Create variable for the output string
        
        // Print what the program will do
        System.out.println("This program will read a string and determine"
                + "if it is a palindrome or not.");
        // Print the instructions for the user
        System.out.println("Enter the string you want to test: ");
        entryString = s.nextLine(); // Scan what the user put
         
        // Create a for cycle to put the string into the stack as characters
        for(int index = 0; index < entryString.length(); index++)
            stack.push(entryString.charAt(index));
        
        // Create a while cycle to pop the characters from top to bottom
        while(!stack.isEmpty())
            outputString += String.valueOf(stack.pop());
        
        // Compare the input string with the output string, and create 
        // an if to print wheter or not the input string is a palindrome
        if(entryString.equals(outputString))
            System.out.println("The string '" + entryString + "' is a palindrome.");
        else
            System.out.println("The string '" + entryString + "' is NOT a palindrome.");
    }
    
}
