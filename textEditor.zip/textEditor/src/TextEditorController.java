import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * Text Editor created with JavaFX and SceneBuilder by Maria Viveros
 */
public class TextEditorController 
{
    @FXML
    private MenuItem newMenuItem;
    
    @FXML
    private MenuItem openMenuItem;
    
    @FXML
    private MenuItem saveMenuItem;
    
    @FXML
    private MenuItem saveAsMenuItem;
    
    @FXML
    private MenuItem exitMenuItem;
    
    @FXML
    private ToggleGroup fontToggle;
    
    @FXML
    private RadioMenuItem monospacedRadioB;
    
    @FXML
    private RadioMenuItem serifRadioB;
    
    @FXML
    private RadioMenuItem sansSerifRadioB;
    
    @FXML 
    private CheckMenuItem italicCheckB;
    
    @FXML
    private CheckMenuItem boldCheckB;
    
    @FXML
    private TextArea textArea;  
    
    @FXML
    private Label fileLabel;        
    
    Stage stage;
    
    FontWeight weight;
    
    /**
     * Class to store file's name and path
     */
    
    private class fileName
    {
        String name;
        String path;
        
        public fileName()
        {
            name = null;
            path = null;
        }
        
        public fileName(String fileName, String filePath)
        {
            name = fileName;
            path = filePath;
        }
        
        public String getFileName()
        {
            return name;
        }
        
        public void setFileName(String newName)
        {
            name = newName;
        }
        
        public String getFilePath()
        {
            return path;
        }
        
        public void setFilePath(String newPath)
        {
            path = newPath;
        }
        
        public void setToNull()
        {
            name = null;
            path = null;
        }
        
        public boolean isNull()
        {
            boolean isItNull;
            
            if(name == null && path == null)
                isItNull = true;
            else
                isItNull = false;
            
            return isItNull;
        }
        
        public void updateLabel()
        {
            fileLabel.setText("File Name: " + name + "\nFile Path: " + path);
        }
    }
    
    fileName file = new fileName();
    
    /**
     * Event Handler to create a new file. It clears the textArea, 
     * and set fileName to null.
     * @param e Event to handle
     */
    public void newFile(ActionEvent e)
    {
        textArea.clear();
        file.setToNull();
        file.updateLabel();
    }
        
    /**
     * Event Handler to open a file. It opens a file chooser, update fileName,
     * and opens the file in the textArea.
     * @param e Event to handle
     */
    public void open(ActionEvent e)
    {
        FileChooser openFile = new FileChooser();
        File selectedFile = openFile.showOpenDialog(stage);
        
        if(selectedFile != null)
        {
            file.setFileName(selectedFile.getName());
            file.setFilePath(selectedFile.getPath());
            
            file.updateLabel();
            
            try
            {
                Scanner s = new Scanner(selectedFile);
                
                while(s.hasNextLine())
                {
                    textArea.appendText(s.nextLine());
                    textArea.appendText("\n");
                }
            }
            catch(IOException ex)
            {
                System.out.println(ex);
            }
        }
    }
    
    /**
     * Event Handler for the Save item. If there is a file selected, 
     * it saves the changes into the same file, if there isn't, it does
     * the same than SaveAs
     * @param e Event to Handle
     */
    public void save(ActionEvent e)
    {
        if(file.isNull())
        {
            FileChooser openFile = new FileChooser();
            File saveFile = openFile.showSaveDialog(stage);
            if(saveFile != null)
            {
                try
                {
                    FileWriter writer = new FileWriter(saveFile);
                    writer.write(textArea.getText());
                    writer.close();
                }
                catch(IOException ex)
                {
                    System.out.print(ex);
                }
            }
        }
        else
        {
            try
            {
                FileWriter writer = new FileWriter(file.getFilePath());
                writer.write(textArea.getText());
                writer.close();
            }
            catch(IOException ex)
            {
                System.out.print(ex);
            }
        }
    }
    
    /**
     * Event Handler for the SaveAS item. It opens a dialog 
     * to choose where to save it, and how to name it, and then
     * it saves what is in the textArea to a new file.
     * @param e Event to Handle
     */
    public void saveAs(ActionEvent e)
    {
        FileChooser openFile = new FileChooser();
        File saveFile = openFile.showSaveDialog(stage);
        if(saveFile != null)
        {
            try
            {
                FileWriter writer = new FileWriter(saveFile);
                writer.write(textArea.getText());
                writer.close();
            }
            catch(IOException ex)
            {
                System.out.print(ex);
            }
        }
    }
 
    /**
     * Event Handler for the exit item. It closes the window.
     * @param e Event to handle
     */
    public void exit(ActionEvent e)
    {
        Platform.exit();
    }
    
    /**
     * Event Handler to change the font type, weight, 
     * and posture in the text on the textArea 
     * @param e Event to Handle
     */
    public void changeFont(ActionEvent e)
    {
        Font textFont = textArea.getFont();
        
        String fontName = textFont.getName();
        double fontSize = textFont.getSize();
        
        FontWeight weight = FontWeight.NORMAL;
        FontPosture posture = FontPosture.REGULAR;
        
        if(monospacedRadioB.isSelected())
            fontName = "Monospaced";
        else if(serifRadioB.isSelected())
            fontName = "Serif";
        else if(sansSerifRadioB.isSelected())
            fontName = "SansSerif";
        
        if(italicCheckB.isSelected())
            posture = FontPosture.ITALIC;
            
        if(boldCheckB.isSelected())
            weight = FontWeight.BOLD;
        
        textArea.setFont(Font.font(fontName, weight, posture, fontSize));
    }
}
