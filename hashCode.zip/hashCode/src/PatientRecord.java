public class PatientRecord 
{
    // Create variables for all the parameters
    int patientId, month, day, year;
    String visitReason, treatment;
    
    /**
     * Create constructor method with all the parameters for the 
     * Patient Record
     * 
     * @param id Numeric patient id
     * @param m  Numeric month of birth
     * @param d  Numeric day of birth
     * @param y  Numeric year of birth
     * @param complaint Reason for the visit
     * @param prescription Treatment for the patient
     * @throws BadVisitDateException 
     */
    public PatientRecord(int id, int m, int d, int y, 
            String complaint, String prescription) throws BadVisitDateException
    {
        patientId = id;
        visitReason = complaint;
        treatment = prescription;
        
        // if sentence to validate the date
        if(m > 12 || m < 1) throw new 
            BadVisitDateException("Month not in range 1-12");
        else if(d > 31 || d < 1) throw new 
            BadVisitDateException("Day not in range 1-31");
        else if(y < 1900) throw new 
            BadVisitDateException("Year not greater than 1900");
        else
        {
            month = m;
            day = d;
            year = y;
        }
    }
    
    /**
     * Gather all parameters into a string to return when 
     * an instance is created
     * 
     * @return All the parameters in the patient record
     */
    public String toString()
    {
        int patient;
        String record, date, complaint, prescribed;
        patient = patientId;
        date = getDate();
        complaint = visitReason;
        prescribed = treatment;
        
        record = "Patient:" + patient + " " + date + "Complaint: " 
                + complaint + " Prescribed: " + prescribed;
        
        return record;
    }
    
    /**
     * Modify the patient ID 
     * 
     * @param id Numeric patient ID
     */
    public void setPatientID(int id)
    {
        patientId = id;
    }
    
    /**
     * Modify a date with numeric input values
     * 
     * @param m Numeric month of birth
     * @param d Numeric day of birth
     * @param y Numeric year of birth
     * @throws BadVisitDateException if it is a non existent date
     */
    public void setDate(int m, int d, int y) throws BadVisitDateException
    {
        if(m > 12 || m < 1) throw new 
            BadVisitDateException("Month not in range 1-12");
        else if(d > 31 || d < 1) throw new 
            BadVisitDateException("Day not in range 1-31");
        else if(y < 1900) throw new 
            BadVisitDateException("Year not greater than 1900");
        else
        {
            month = m;
            day = d;
            year = y;
        }
    }
    
    /**
     * Modify the visit reason
     * 
     * @param reason Reason for the visit
     */
    public void setVisitReason(String reason)
    {
        visitReason = reason;
    }
    
    /**
     * Modify the treatment
     * 
     * @param prescription Treatment for the patient
     */
    public void setTreatment(String prescription)
    {
        treatment = prescription;
    }
    
    /**
     * Get the Id from the patient
     * 
     * @return patient ID
     */
    public int getPatientId()
    {
        return patientId;
    }
    
    /**
     * Get the date into a string
     * 
     * @return date of birth
     */
    public String getDate()
    {
        return "[" + month + "/" + day + "/" + year + "]";
    }
    
    /**
     * Get the reason for the visit
     * 
     * @return Reason of visit
     */
    public String getVisitReason()
    {
        return visitReason;
    }
    
    /**
     * Get the treatment for the patient
     * 
     * @return treatment
     */
    public String getTreatment()
    {
        return treatment;
    }
    
    /**
     * Make a hash code for the patients
     * 
     * @return hash code
     */
    public int hashCode()
    {
        String date = getDate();
        int code = patientId * date.hashCode();
        
        if(code < 0)
            code = code + Integer.MAX_VALUE;
        
        return code;
    }
    
    /**
     * Method to compare elements to check if they are
     * from the same class
     * 
     * @param other object to be compared with
     * @return boolean to see if they are equal or not
     */
    public boolean equals(Object other)
    {
        boolean isEqual;
        
        if(getClass() != other.getClass())
            isEqual = false;
        else if(getClass() == other.getClass())
            isEqual = true;
        else
            isEqual = false;
        
        return isEqual;
    }
}
