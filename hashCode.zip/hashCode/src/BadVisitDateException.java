public class BadVisitDateException extends Exception 
{
    /**
     * Exception if the date is non existent
     * 
     * @param error kind oof error
     */
    public BadVisitDateException(String error)
    {
        super("Creation failed BadVisitDateException: " + error);
    }
}
