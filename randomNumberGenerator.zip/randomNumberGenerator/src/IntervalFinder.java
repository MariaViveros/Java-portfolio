/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author majoviveros
 */
public class IntervalFinder 
{
    public static boolean inArray(int input, Integer[] array) 
    {
        return binarySearch(array, 0, array.length - 1, input); 
    } // end inArray
    
    public static int locateLow(int i, Integer[] a)
    {
        return locateLow(a, 0, a.length - 1, i);
    }
    
    public static int locateHigh(int i, Integer[] a)
    {
        return locateHigh(a, 0, a.length - 1, i);
    }
    
    private static boolean binarySearch(Integer[] anArray, 
            int first, int last, int desiredItem)
    {
        boolean found = false;
        
        int mid = first + (last - first) / 2;
        
        if (first > last)
            found = false;
        else if (desiredItem == anArray[mid])
            found = true;
        else if (desiredItem < anArray[mid])
            found = binarySearch(anArray, first, mid - 1, desiredItem);
        else
            found = binarySearch(anArray, mid + 1, last, desiredItem); 
            
        return found;
    } // end binarySearch
    
    private static int locateLow(Integer[] anArray, 
            int first, int last, int desiredItem)
    {
        int indexLow = 0;
        
        boolean equal = inArray(desiredItem, anArray);
        
        int mid = first + (last - first) / 2;
        
        if(equal = true)
            indexLow = getIndex(anArray, desiredItem);
        
        if(anArray[0] > desiredItem)
        {
            indexLow = -1;
        }
        else if(desiredItem < anArray[mid])
        {
            for(int i = 0; i < mid; i++)
            {
                if(desiredItem < anArray[i] && desiredItem > anArray[i - 1])
                {
                    indexLow = i - 1;
                }
            }
        }
        else
        {
            for(int i = mid; i < anArray.length; i++)
            {
                if(desiredItem < anArray[i] && desiredItem > anArray[i - 1])
                {
                    indexLow = i - 1;
                }
            }
        }
            
        return indexLow;
    } // end locateLow
    
    private static int locateHigh(Integer[] anArray, 
            int first, int last, int desiredItem)
    {
        int indexHigh = 0;
        
        boolean equal = inArray(desiredItem, anArray);
        
        int mid = first + (last - first) / 2;
        
        if(equal = true)
            indexHigh = getIndex(anArray, desiredItem);
        
        if(anArray[anArray.length - 1] < desiredItem)
        {
            indexHigh = anArray.length;
        }
        else if(desiredItem < anArray[mid])
        {
            for(int i = 0; i < mid; i++)
            {
                if(desiredItem < anArray[i] && desiredItem > anArray[i - 1])
                {
                    indexHigh = i;
                }
            }
        }
        else
        {
            for(int i = mid; i < anArray.length; i++)
            {
                if(desiredItem < anArray[i] && desiredItem > anArray[i - 1])
                {
                    indexHigh = i;
                }
            }
        }
            
        return indexHigh;
    } // end locateLHigh
    
    private static int getIndex(Integer[] array,  int element)
    {
        int elementIndex = 0;
        
        for(int index = 0; index < array.length; index++)
        {
            if(array[index] == element)
            {
                elementIndex = index;
            }
        }
        
        return elementIndex;
    }
}
