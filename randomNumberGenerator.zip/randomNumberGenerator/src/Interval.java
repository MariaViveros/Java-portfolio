/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author majoviveros
 */
public class Interval 
{
    public static int getLow(Integer[] array)
    {
        int low = array[0];
        
        for(int index = 0; index < array.length; index++)
        {
            if(array[index] < low)
                low = array[index];
        }
        
        return low;
    }
    
    public static int getHigh(Integer[] array)
    {
        int high = array[array.length - 1];
        
        for(int index = 0; index < array.length; index++)
        {
            if(array[index] > high)
                high = array[index];
        }
        
        return high;
    }
}
