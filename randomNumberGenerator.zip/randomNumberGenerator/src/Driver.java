import java.util.*;
import java.io.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author majoviveros
 */
public class Driver 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Integer[] array = randomArray();
        Scanner scan = new Scanner(System.in);
        Interval interval = new Interval();
        IntervalFinder find = new IntervalFinder();
        
        sortArray(array);
        
        System.out.println("The sorted data is: \n" + getString(array));
        
        System.out.println("Enter the list of integer values (all on one line), "
                + "or just press enter if you are done.");
        

        String[] noIntegers = scan.nextLine().trim().split(" ");
        
        Integer[] inputs = new Integer[noIntegers.length];

        for(int i = 0; i < noIntegers.length; i++)
        {
            inputs[i] = Integer.parseInt(noIntegers[i]);
        }    
        
        int lowInterval = interval.getLow(inputs);
        int highInterval = interval.getHigh(inputs);
            
        int low = find.locateLow(lowInterval, array);
        int high = find.locateHigh(highInterval, array);
        
        System.out.println("The pair of indices that bound the interval "
            + "containing the given values is (" + low + ", " + high + ")");
        
    }
    
    private static Integer[] randomArray()
    {
        Integer randArray[] = new Integer[15];
        Random random = new Random();
        
        for(int i = 0; i< randArray.length; i++)
        {
            int value = random.nextInt(100);
            randArray[i] = new Integer(value);
        }
        
        return randArray;
    }
    
    private static String getString(Object [] data)
    {
        String result = new String("[ ");
        
        for(int i = 0; i< data.length; i++)
        {
            result = result + data[i].toString() + " ";
        }
        
        result = result + "]";
        
        return result;
    }
    
    private static void sortArray(Integer[] randomArray)
    {
        for(int index = 0; index < randomArray.length -1; index++)
        {
            int nextSmallestIndex = getSmallestIndex(randomArray, index, randomArray.length -1);
            swap(randomArray, index, nextSmallestIndex);
        }
    }
    
    private static int getSmallestIndex(Integer[] array,  int first, int last)
    {
        int min = array[first];
        int minIndex = first;
        
        for(int index = first + 1; index <= last; index++)
        {
            if(array[index] < min)
            {
                min = array[index];
                minIndex = index;
            }
        }
        
        return minIndex;
    }
    
    private static void swap(Integer[] array, int a, int b)
    {
        int temp = array[a];
        array[a] = array[b];
        array[b] = temp;
    }
    
}
